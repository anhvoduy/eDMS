﻿$localFileInfo = "E:\Working\Migration_20151115"

$Url = "https://publicisgroupe.sharepoint.com"
$SiteUrl = "https://publicisgroupe.sharepoint.com/sites/ignite"
$LocalPath = "E:\Working\Backup"
$AdminUsername = "adm-moishar@publicisgroupe.onmicrosoft.com"

Write-Host "Please enter password for $($SiteUrl):" -NoNewline
$pwd = Read-Host -AsSecureString
#$pwd = 'intrepidS$5'

# Default Language is English
$lcid = "1033"

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Taxonomy")

# connect/authenticate to SharePoint Online and get ClientContext object.. 
$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl)
$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($AdminUsername, $pwd)
$ctx.Credentials = $credentials

function Select-FileDialog(){
	param([string]$Title,[string]$Directory,[string]$Filter="CSV Files (*.csv)|*.csv")
	[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
	$objForm = New-Object System.Windows.Forms.OpenFileDialog
	$objForm.InitialDirectory = $Directory
	$objForm.Filter = $Filter
	$objForm.Title = $Title
	$objForm.ShowHelp = $true
	
	$Show = $objForm.ShowDialog()
	
	if ($Show -eq "OK")
	{
		return $objForm.FileName
	}
	else
	{
		exit
	}
}


function Download-File([string]$UserName, [string]$Password,[string]$FileUrl,[string]$DownloadPath){
    if([string]::IsNullOrEmpty($Password)) {
      $SecurePassword = Read-Host -Prompt "Enter the password" -AsSecureString 
    }
    else {
      $SecurePassword = $Password | ConvertTo-SecureString -AsPlainText -Force
    }
    $fileName = [System.IO.Path]::GetFileName($FileUrl)
    $downloadFilePath = [System.IO.Path]::Combine($DownloadPath,$fileName)


    $client = New-Object System.Net.WebClient 
    $client.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($UserName, $SecurePassword)
    $client.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
    $client.DownloadFile($FileUrl, $downloadFilePath)
    $client.Dispose()
}

function Get-Documents($ctx, $list, $localList){
    $ctx.Load($list.RootFolder)
    $ctx.ExecuteQuery()
    Write-Host "Loading document library: " $list.RootFolder.ServerRelativeUrl

    $camlQuery = New-Object Microsoft.SharePoint.Client.CamlQuery
    $camlQuery.FolderServerRelativeUrl = $list.RootFolder.ServerRelativeUrl
    $camlQuery.ViewXml = "<View Scope='Recursive'><RowLimit>100</RowLimit></View><OrderBy Override='TRUE'><FieldRef Name='ID'/></OrderBy>"
                
    $ctx.Load($list)
    $ctx.ExecuteQuery()

    $listItemCollection = $list.GetItems($camlQuery);
    $ctx.Load($listItemCollection);
    $ctx.ExecuteQuery()    

    foreach($item in $listItemCollection){
        Write-Host "Download File Id:" $item.Id "| File Name:" $item["FileLeafRef"] "| RelativeUrl:" $item["FileRef"];
                                        
        # fromFile & toFile
        $file = $ctx.Web.GetFileByServerRelativeUrl($item["FileRef"])        

        $fromFile = $Url + $item["FileRef"]
        Write-Host "From File:" $fromFile
        $toFile = $localList + '\' + $item["FileLeafRef"]
        Write-Host "To File:" $toFile
        
        Download-File -UserName $AdminUsername -Password 'intrepidS$5' -FileUrl $fromFile -DownloadPath $localList
        
        Write-Host "-----"
    }
}

function Build-CalmQuery($itemProperties) {
    $selectProperties = "<ViewFields>";
    foreach($property in $itemProperties){
        # check is lookup column
        if($property -eq "CEP_Page"){
            $fieldRef = [string]::Format("<FieldRef Name='{0}' LookupId='TRUE' />",$property)
        }else{
            $fieldRef = [string]::Format("<FieldRef Name='{0}' />",$property)
        }        
        $selectProperties = $selectProperties + $fieldRef
    }
    $selectProperties = $selectProperties + "</ViewFields>";
    return $selectProperties;
}

function Get-ItemById($listTitle, $itemId){    
    $list = $ctx.Web.Lists.GetByTitle($listTitle);
    $ctx.Load($list);
    $ctx.ExecuteQuery();
    
    $listItem=$list.GetItemById($itemId);
    $ctx.Load($listItem);
    $ctx.ExecuteQuery();
       
    $itemTitle = $listItem["Title"];
    return $itemTitle;
}

function Get-ItemProperties($ctx, $list, $itemProperties){
    $listOutputFile = $LocalPath + $list.Title + ".csv"

    $ctx.Load($list.RootFolder)
    $ctx.ExecuteQuery()    

    $camlQuery = New-Object Microsoft.SharePoint.Client.CamlQuery
    $camlQuery.FolderServerRelativeUrl = $list.RootFolder.ServerRelativeUrl    
    $camlQuery.ViewXml = "<View Scope='Recursive'>{0}<RowLimit>500</RowLimit></View>"

    $selectProperties = Build-CalmQuery $itemProperties
    $camlQuery.ViewXml = [string]::Format($camlQuery.ViewXml,$selectProperties)
                
    $ctx.Load($list)
    $ctx.ExecuteQuery()     

    do
    {
        $listItemCollection = $list.GetItems($camlQuery);        
        $ctx.Load($listItemCollection);
        $ctx.ExecuteQuery()
        $camlQuery.ListItemCollectionPosition = $listItemCollection.ListItemCollectionPosition

        foreach($item in $listItemCollection){        
            $itemFields = @{
                Id = $item.Id;
                SiteUrl = $list.ParentWebUrl;
                ListUrl = $list.RootFolder.ServerRelativeUrl;

                CreatedBy = $item["Author"].LookupValue;
                Created = $item["Created"];
                ModifiedBy = $item["Editor"].LookupValue;
                Modified = $item["Modified"];
            }

            foreach($property in $itemProperties){
                if($property -eq "CEP_ParentNode"){
                    $itemFields.Add($property,$item[$property].LookupValue)
                }elseif($property -eq "HowTo_ContentID"){
                    $itemFields.Add($property,$item[$property].LookupValue)
                }elseif($property -eq "SubCategoryMainID"){
                    $itemFields.Add($property,$item[$property].LookupValue)
                }elseif($property -eq "CEP_Category"){
                    $itemFields.Add($property,$item[$property].LookupValue)
                }elseif($property -eq "CEP_System"){
                    $itemFields.Add($property,$item[$property].LookupValue)
                }elseif($property -eq "CEP_Page"){
                    if($item[$property].LookupValue.Length -gt 0){
                        $itemTitle = Get-ItemById "Pages" $item[$property].LookupValue
                        $itemFields.Add($property, $itemTitle)
                    }else{
                        $itemFields.Add($property,$item[$property].LookupValue)
                    }                    
                }elseif($property -eq "Author" -or $property -eq "Editor" -or $property -eq "TicketAuthor"){
                    $itemFields.Add($property,$item[$property].Email)
                }elseif($property -eq "HyperLink" -or $property -eq "CEP_ExternalLink" -or $property -eq "HowTo_LinkUrl" -or $property -eq "HowTo_ExternalLink"){
                    $itemFields.Add($property,$item[$property].Url)
                }elseif($property -eq "ImageMD" -or $property -eq "ImageSM" -or $property -eq "ImageXS"){
                    $itemFields.Add($property,$item[$property].Url)
                }else{
                    $itemFields.Add($property,$item[$property])  
                }
            }

            $listInfo = New-Object PSObject -Property $itemFields
            $listInfo | Export-Csv $listOutputFile -NoTypeInformation -Append
        }
    }
    while ($camlQuery.ListItemCollectionPosition -ne $null)    
    Write-Host "Export Information of list: " $list.Title " is successful."    
}



## ----- Main Function  ----- ##
if (!$ctx.ServerObjectIsNull.Value){ 
    # write Site Info
    $outputSiteInfo = $LocalPath + "\" + "SiteCollection-Info-" + (Get-Date -format yyyyMMdd-HHmmss) + ".csv"
    Write-Host "Output file:" $outputSiteInfo

    # create folder in Local Path
    $LocalPath = $LocalPath + "\BackupSiteCollection_" + (Get-Date -format yyyyMMdd-HHmmss) +"\"
    New-Item $LocalPath -type directory
    Write-Host "Create Folder in local path: " $LocalPath

    # connect to SharePoint Online
    Write-Host "Connected to SharePoint Online: " $ctx.Url -ForegroundColor Green
    
    # load Current Site
    $currentSite = $ctx.Site
    $ctx.Load($currentSite)
    $ctx.ExecuteQuery()
    Write-Host "Loading Current Site: "  $currentSite.Url    
    
    # load Current Web
    $currentWeb = $ctx.Web
    $ctx.Load($currentWeb)
    $ctx.ExecuteQuery()
    Write-Host "Loading Current Web:" $currentWeb.Url    
    
    # load all lists of Site Collection
    $lists = $currentWeb.Lists
    $ctx.Load($lists)
    $ctx.ExecuteQuery()
    Write-Host "Loading all lists of Site Collection :" $lists.Count " item(s)"    
    
    # select File to Backup Content Data
    Write-Host "Select File to Backup Content Data :"
    $fileName = Select-FileDialog -Title "Select CSV file to Backup Content Data" -Directory $localFileInfo
    $backupList = Import-Csv $fileName        

    # loop lists in Site Collection
    foreach($list in $lists)
    {   
        #Write-Host "List Title:" $list.Title;
        #Write-Host "EntityTypeName:" $list.EntityTypeName;
        #Write-Host "Base Template:" $list.BaseTemplate;
        #Write-Host "Base Type:" $list.BaseType;
        #Write-Host "Items Count:" $list.ItemCount;
        #Write-Host "---"
        
        $itemProperties = @{
            ListTitle = $list.Title;
            EntityTypeName = $list.EntityTypeName;
            BaseType = $list.BaseType;
            BaseTemplate = $list.BaseTemplate;
            ItemCount = $list.ItemCount
        }
    
        $listInfo = New-Object PSObject -Property $itemProperties
        $listInfo | Export-Csv $outputSiteInfo -NoTypeInformation -Append
        
        # start to write information to csv file
        foreach($bkList in $backupList){
            
            # check Internal Name to start backup
            if($list.EntityTypeName -eq $bkList.ListName) {
                Write-Host ""
                Write-Host "Start to backup List Name:" $bkList.ListName -ForegroundColor Yellow                                               
                Write-Host "Creating Folder of List:" $list.Title " in local path." -ForegroundColor Cyan
                $listPath = $LocalPath + $list.Title
                New-Item $listPath -type directory
                            
                Write-Host "Start reading item(s) in List:" $list.Title -ForegroundColor Cyan
                $itemProperties = $bkList.Properties.Split(',')
                Get-ItemProperties $ctx $list $itemProperties
                            
                if($list.BaseType -eq "DocumentLibrary")
                {
                    Write-Host "Reading file(s) in List:" $list.Title -ForegroundColor Cyan
                    Get-Documents $ctx $list $listPath
                }
            
                Write-Host "End of backup List Name:" $bkList.ListName -ForegroundColor Yellow                
            }            
        }
    }
}
