﻿Import-Module microsoft.online.sharepoint.powershell
$credential = get-credential

$SiteUrl = "https://publicisgroupe-admin.sharepoint.com/"
Connect-SPOService -Url $SiteUrl -Credential $credential
Remove-SPODeletedSite -Identity https://publicisgroupe.sharepoint.com/sites/cepdev08

#$Url = "https://publicisgroupe.sharepoint.com"
#$SiteUrl = "https://publicisgroupe-admin.sharepoint.com/"
#$LocalPath = "E:\Working\BackupSiteCollection_20151111-165411"
#$AdminUsername = "adm-moishar@publicisgroupe.onmicrosoft.com"
#
#Write-Host "Please enter password for $($SiteUrl):" -NoNewline
#$pwd = Read-Host -AsSecureString
##$pwd = 'intrepidS$5'
#
## Default Language is English
#$lcid = "1033"
#
#[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
#[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")
#[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Taxonomy")
#
## connect/authenticate to SharePoint Online and get ClientContext object.. 
#$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl)
#$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($AdminUsername, $pwd)
#$ctx.Credentials = $credentials
##
### connect to SharePoint Online
##Write-Host "Connected to SharePoint Online: " $ctx.Url -ForegroundColor Green
#
#Connect-SPOService - Connect-SPOService -Url $SiteUrl -Credential $credentials
##Remove-SPODeletedSite -Identity https://publicisgroupe.sharepoint.com/sites/ceptemp