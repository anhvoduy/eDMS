﻿$localFileInfo = "C:\Working\Migration"

$Url = "https://publicisgroupe.sharepoint.com"
$SiteUrl = "https://publicisgroupe.sharepoint.com/sites/cep_test/en-us"
$LocalPath = "E:\Working\Backup\BackupSiteCollection_20151116-103143"
$AdminUsername = "adm-moishar@publicisgroupe.onmicrosoft.com"

Write-Host "Please enter password for $($SiteUrl):" -NoNewline
$pwd = Read-Host -AsSecureString
#$pwd = 'intrepidS$5'

# Default Language is English
$lcid = "1033"

# constant List/Library Name
$navigation = "Navigation"
$pageLibrary = "Pages"
$homeNotificationCategory = "Home Notification Category"
$homeNotificationSystem = "Home Notification System"
$subCategoryProductOverview = "Sub-Category Product Overview"
$howToContent = "How To Content"
$homeMyFavoriteAdmin = "Home My Favorite Admin"

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Taxonomy")

# connect/authenticate to SharePoint Online and get ClientContext object.. 
$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl)
$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($AdminUsername, $pwd)
$ctx.Credentials = $credentials

function Select-FileDialog(){

	param([string]$Title,[string]$Directory,[string]$Filter="CSV Files (*.csv)|*.csv")
	[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
	$objForm = New-Object System.Windows.Forms.OpenFileDialog
	$objForm.InitialDirectory = $Directory
	$objForm.Filter = $Filter
	$objForm.Title = $Title
	$objForm.ShowHelp = $true
	
	$Show = $objForm.ShowDialog()
	
	if ($Show -eq "OK")
	{
		return $objForm.FileName
	}
	else
	{
		exit
	}
}


function Upload-File($entityTypeName, $listId, $listTitle, $itemProperties){
    Write-Host "Uploading File" $itemProperties.FileLeafRef " to Library:" $listTitle;    

    # retrieve document library
    $documentLibrary = $ctx.Web.Lists.GetByTitle($listTitle)
    $ctx.Load($documentLibrary)
    $ctx.ExecuteQuery()

    # upload file    
    $fromFile = $LocalPath + "\" + $listTitle + "\" + $itemProperties.FileLeafRef
    Write-Host "From File:" $fromFile
              
    # load Document Library & RootFolder
    $rootFolder = $documentLibrary.RootFolder;
    $ctx.Load($rootFolder);
    $ctx.ExecuteQuery();   
    
    # open FileStream
    $fileStream = ([System.IO.FileInfo] (Get-Item $fromFile)).OpenRead()
    $fileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
    $fileCreationInfo.Overwrite = $true
    $fileCreationInfo.ContentStream = $fileStream
    $fileCreationInfo.Url = $rootFolder.ServerRelativeUrl + "/" + $itemProperties.FileLeafRef
    
    # upload file to SharePoint
    $uploadFile = $documentLibrary.RootFolder.Files.Add($fileCreationInfo)    
    $ctx.Load($uploadFile.ListItemAllFields)
    $ctx.ExecuteQuery()

    # update metadata properties     
    $listItem = $uploadFile.ListItemAllFields
    Update-ListItem $entityTypeName $listId $listTitle $listItem.Id $itemProperties

    # update Author & Editor & Created & Modified    
    Update-AuthorEditorCreatedModified $entityTypeName $listId $listTitle $listItem.Id $itemProperties

    # write logs
    $toFile = $Url + $fileCreationInfo.Url
    Write-Host "To File:" $toFile
    Write-Host "File was uploaded successful to Document Library:" $documentLibrary.Title
    Write-Host "-----"
}

function Get-ItemByTitle($listTitle, $itemTitle){
    # connect/authenticate to SharePoint Online and get ClientContext object.. 
    $clientContext = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl);
    $clientContext.Credentials = $credentials;
        
    $query = "<Query>
               <Where>
                  <Eq>
                     <FieldRef Name='Title' />
                     <Value Type='Text'>" + $itemTitle +"</Value>
                  </Eq>
               </Where>
               <OrderBy><FieldRef Name='Title' /></OrderBy>
            </Query>
            <ViewFields>
               <FieldRef Name='ID' />
               <FieldRef Name='Title' />
               <FieldRef Name='FileLeafRef' />
               <FieldRef Name='FileDirRef' />
            </ViewFields>"
    $camlQuery = New-Object Microsoft.SharePoint.Client.CamlQuery;    
    $camlQuery.ViewXml = $query;

    $list = $clientContext.Web.Lists.GetByTitle($listTitle);
    $clientContext.Load($list);
    $clientContext.ExecuteQuery();
    
    $listItemCollection = $list.GetItems($camlQuery);
    $clientContext.Load($listItemCollection);
    $clientContext.ExecuteQuery()
       
    $itemID = 0
    foreach($item in $listItemCollection){        
        if($item["Title"].length -gt 0 -and $itemTitle.length -gt 0 -and $item["Title"].TrimEnd().TrimStart() -eq $itemTitle.TrimEnd().TrimStart()){
            $itemID = $item["ID"];            
            break;
        }
    }
    return $itemID;
}

function Create-ListItem($entityTypeName, $listId, $listTitle, $itemProperties){
    Write-Host "Creating item in list:" $listTitle;            

    # load destinationList
    $currentList = $ctx.Web.Lists.GetByTitle($listTitle);    
    $ctx.Load($currentList);    
        
    # create new item
    $listItemCreationInformation = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation;
    $listItem = $currentList.AddItem($listItemCreationInformation);                    
    $listItem["Title"] = $itemProperties.Title
    $listItem.Update();
    $ctx.ExecuteQuery();

    # write log
    Write-Host "New item in list:" $currentList.Title " was created successful.";

    # update metadata properties
    Update-ListItem $entityTypeName $listId $listTitle $listItem.Id $itemProperties

    # update Author & Editor & Created & Modified    
    Update-AuthorEditorCreatedModified $entityTypeName $listId $listTitle $listItem.Id $itemProperties
}

function Update-ListItem($entityTypeName, $listId, $listTitle, $itemId, $itemProperties){    
    Write-Host "Updating item $itemId in list:" $listTitle
    
    if($entityTypeName -eq "NavigationListList"){
        Update-NavigationListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "Pages"){
        Update-Pages $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "CategoryHeroBarListList"){
        Update-CategoryHeroBarListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "CategoryLinkTitleListList"){
        Update-CategoryLinkTitleListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "CategoryOverviewListList"){
        Update-CategoryOverviewListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "CategoryToolsListList"){
        Update-CategoryToolsListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "CategorySubCategoryListList"){
        Update-CategorySubCategoryList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "CustomerCareListList"){
        Update-CustomerCareListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "SelfServiceListList"){
        Update-SelfServiceListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "LanguageInfoListList"){
        Update-LanguageInfoListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "Documents"){
        Update-Documents $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeHeroBarImageListList"){
        Update-HomeHeroBarImageListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeHeroBarQuoteListList"){
        Update-HomeHeroBarQuoteListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeMyFavoriteAdminListList"){
        Update-HomeMyFavoriteAdminListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeMyFavoriteUserListList"){
        Update-HomeMyFavoriteUserListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeNotificationCategoryListList"){
        Update-HomeNotificationCategoryListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeNotificationSystemListList"){
        Update-HomeNotificationSystemListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeNotificationListList"){
        Update-HomeNotificationListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "PublishingImages"){
        Update-PublishingImages $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "OurTeam_x005f_HeroBarLibraryList"){
        Update-OurTeam_x005f_HeroBarLibraryList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "OurTeam_x005f_ContentLibraryList"){
        Update-OurTeam_x005f_ContentLibraryList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "SubCategoryMainListList"){
        Update-SubCategoryMainListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "SubCategoryChildListList"){
        Update-SubCategoryChildListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HomeSpotlightListList"){
        Update-HomeSpotlightListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HowTo_x005f_HeroBarLibraryList"){
        Update-HowTo_x005f_HeroBarLibraryList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HowTo_x005f_ContentLibraryList"){
        Update-HowTo_x005f_ContentLibraryList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "HowTo_x005f_HelpfulListList"){
        Update-HowTo_x005f_HelpfulListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductContactListList"){
        Update-ProductContactListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductCostListList"){
        Update-ProductCostListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductFAQListList"){
        Update-ProductFAQListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductFeatureBenefitListList"){
        Update-ProductFeatureBenefitListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductFeatureListList"){
        Update-ProductFeatureListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductHeroBarListList"){
        Update-ProductHeroBarListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductImageListList"){
        Update-ProductImageListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductOverviewListList"){
        Update-ProductOverviewListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductProofpointListList"){
        Update-ProductProofpointListList $listId $listTitle $itemId $itemProperties
    }elseif($entityTypeName -eq "ProductVideoListList"){
        Update-ProductVideoListList $listId $listTitle $itemId $itemProperties
    }

    Write-Host "Update item $itemId in list:" $listTitle " is successful."
}

function Update-AuthorEditorCreatedModified($entityTypeName, $listId, $listTitle, $itemId, $itemProperties){    
    Write-Host "Updating item: $itemId with Author:" $itemProperties.Author
    Write-Host "Updating item: $itemId with Editor:" $itemProperties.Editor
 
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item    
    $listItem = $list.GetItemById($itemId)
    
    if($itemProperties.Author.Length -gt 0) {
        $listItem["Author"] = $ctx.Web.EnsureUser($itemProperties.Author)
    }
    
    if($itemProperties.Editor.Length -gt 0) {
        $listItem["Editor"] = $ctx.Web.EnsureUser($itemProperties.Editor)
    }    
    
    if($itemProperties.Created.Length -gt 0){
        $listItem["Created"] = $itemProperties.Created
    }
    
    if($itemProperties.Modified.Length -gt 0){
        $listItem["Modified"] = $itemProperties.Modified
    }        
    
    # update item
    $listItem.Update()
    $ctx.Load($listItem)
    $ctx.ExecuteQuery()    
}

function Update-ManagedMetadata($entityTypeName, $listId, $listTitle, $itemId, $itemProperties){    
    Write-Host "Updating item: $itemId with ManagedMetadata Column: ..."
}



# update list item properties
function Update-NavigationListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["AutoCreate"] = $itemProperties.AutoCreate
    $listItem["CEP_LinkURL"] = $itemProperties.CEP_LinkURL
    $listItem["CEP_Order"] = $itemProperties.CEP_Order
    $listItem["CEP_Order"] = $itemProperties.CEP_Order
    $listItem["CEP_PageID"] = $itemProperties.CEP_PageID

    # lookup column
    $parentNode = Get-ItemByTitle $navigation $itemProperties.CEP_ParentNode
    if($parentNode -gt 0){
        $listItem["CEP_ParentNode"] = $parentNode
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-Pages($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)

    # lookup column
    $parentNode = Get-ItemByTitle $navigation $itemProperties.CEP_ParentNode
    if($parentNode -gt 0){
        $listItem["CEP_ParentNode"] = $parentNode
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-CategoryHeroBarListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["ExternalLink"] = $itemProperties.ExternalLink
    $listItem["HeroBarDescription"] = $itemProperties.HeroBarDescription    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-CategoryLinkTitleListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-CategoryOverviewListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["Descriptions"] = $itemProperties.Descriptions    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-CategoryToolsListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CEP_Description"] = $itemProperties.CEP_Description
    $listItem["CEP_ExternalLink"] = $itemProperties.CEP_ExternalLink

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-CategorySubCategoryList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["ExternalLink"] = $itemProperties.ExternalLink
    $listItem["ServiceDescription"] = $itemProperties.ServiceDescription

    # FieldValueUrl
    $fieldUrlValue = New-Object Microsoft.SharePoint.Client.FieldUrlValue
    $fieldUrlValue.URL = $itemProperties.ImageLink
    $fieldUrlValue.Description = $itemProperties.ImageLink
    #$listItem["ImageLink"] = [Microsoft.SharePoint.Client.FieldUrlValue] $fieldUrlValue

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }
    
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-CustomerCareListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CustomerCare_Url"] = $itemProperties.CustomerCare_Url    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-SelfServiceListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["SelfService_Url"] = $itemProperties.SelfService_Url

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-LanguageInfoListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["SiteName"] = $itemProperties.SiteName

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-Documents($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeHeroBarImageListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CEP_Location"] = $itemProperties.Location    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeHeroBarQuoteListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CEP_Index"] = $itemProperties.CEP_Index    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeMyFavoriteAdminListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["HyperLink"] = $itemProperties.HyperLink    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeMyFavoriteUserListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["HyperLink"] = $itemProperties.HyperLink
    $listItem["Active"] = $itemProperties.Active
    #$listItem["AdminID"] = $itemProperties.AdminID

    # lookup column
    if($itemProperties.AdminID.Length -gt 0){
        $adminID = Get-ItemByTitle $homeMyFavoriteAdmin $itemProperties.Title.TrimEnd().TrimStart()
        if($adminID -gt 0){
            $listItem["AdminID"] = $adminID
        }
    }    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeNotificationCategoryListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeNotificationSystemListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeNotificationListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CEP_Description"] = $itemProperties.CEP_Description
    
    # lookup column
    $categoryID = Get-ItemByTitle $homeNotificationCategory $itemProperties.CEP_Category
    if($categoryID -gt 0){
        $listItem["CEP_Category"] = $categoryID
    }

    # lookup column
    $systemID = Get-ItemByTitle $homeNotificationSystem $itemProperties.CEP_System
    if($systemID -gt 0){
        $listItem["CEP_System"] = $systemID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-PublishingImages($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-OurTeam_x005f_HeroBarLibraryList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CEP_SubTitle"] = $itemProperties.CEP_SubTitle
    
    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-OurTeam_x005f_ContentLibraryList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["CEP_Description"] = $itemProperties.CEP_Description
    $listItem["Title"] = $itemProperties.CEP_Position
    
    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-SubCategoryMainListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["Image"] = $itemProperties.Image
    $listItem["ContentBody"] = $itemProperties.ContentBody
    $listItem["ContentTitle"] = $itemProperties.ContentTitle
    $listItem["CEP_ExternalLink"] = $itemProperties.CEP_ExternalLink
    $listItem["CEP_ProductName"] = $itemProperties.Title
    
    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-SubCategoryChildListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)
    $listItem["ContentBody"] = $itemProperties.ContentBody    
    
    # lookup column
    $subCategoryMainID = Get-ItemByTitle $subCategoryProductOverview $itemProperties.SubCategoryMainID
    if($subCategoryMainID -gt 0){
        $listItem["SubCategoryMainID"] = $subCategoryMainID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HomeSpotlightListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_ForceDisplay"] = $itemProperties.ForceDisplay    
    $listItem["CEP_Body"] = $itemProperties.Body
    $listItem["CEP_Activated"] = $itemProperties.Activated
    $listItem["CEP_SpotlightAction"] = $itemProperties.SpotlightAction

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HowTo_x005f_HeroBarLibraryList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["HowTo_Description"] = $itemProperties.HowTo_Description    
    $listItem["HowTo_Name"] = $itemProperties.HowTo_Name

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HowTo_x005f_ContentLibraryList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["HowTo_Description"] = $itemProperties.HowTo_Description    
    $listItem["HowTo_ExternalLink"] = $itemProperties.HowTo_ExternalLink
    
    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-HowTo_x005f_HelpfulListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["HowTo_Content"] = $itemProperties.HowTo_Content
    $listItem["HowTo_LinkUrl"] = $itemProperties.HowTo_LinkUrl

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }

    $howTo_ContentID = Get-ItemByTitle $howToContent $itemProperties.HowTo_ContentID
    if($howTo_ContentID -gt 0){
        $listItem["HowTo_ContentID"] = $howTo_ContentID
    }
    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductContactListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_Content"] = $itemProperties.Content    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductCostListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_ProductCostDesc"] = $itemProperties.CEP_ProductCostDesc    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductFAQListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["productAnswer"] = $itemProperties.productAnswer    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductFeatureBenefitListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_Description_FullHtml"] = $itemProperties.Description1    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductFeatureListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["FeatureDescription"] = $itemProperties.FeatureDescription
    $listItem["Benefits"] = $itemProperties.Benefits

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductHeroBarListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["ProductPhrase"] = $itemProperties.ProductPhrase
    $listItem["ProductName"] = $itemProperties.ProductName

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductImageListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_ProductImageContent"] = $itemProperties.CEP_ProductImageContent
    $listItem["CEP_ProductImageLinkUrl"] = $itemProperties.CEP_ProductImageLinkUrl

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductFeatureListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["FeatureDescription"] = $itemProperties.FeatureDescription
    $listItem["Benefits"] = $itemProperties.Benefits

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductOverviewListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_ProductOverviewDesc"] = $itemProperties.CEP_ProductOverviewDesc    

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductProofpointListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)
    
    # get item
    $listItem = $list.GetItemById($itemId)    
    $listItem["CEP_Content"] = $itemProperties.Content
    $listItem["CEP_LinkUrl"] = $itemProperties.CEP_LinkUrl

    # lookup column
    $pageID = Get-ItemByTitle $pageLibrary $itemProperties.CEP_Page
    if($pageID -gt 0){
        $listItem["CEP_Page"] = $pageID
    }    
       
    $listItem.Update()
    $ctx.ExecuteQuery()
}

function Update-ProductVideoListList($listId, $listTitle, $itemId, $itemProperties){
    # load splist
    $list = $ctx.Web.Lists.GetById($listId)
    $ctx.Load($list)        
    $ctx.ExecuteQuery()
}



## ----- Main Function  ----- ##
if (!$ctx.ServerObjectIsNull.Value) {
    # connect to SharePoint Online
    Write-Host "Connected to SharePoint Online: " $ctx.Url -ForegroundColor Green
    
    # load Current Site
    $currentSite = $ctx.Site
    $ctx.Load($currentSite)
    $ctx.ExecuteQuery()
    Write-Host "Loading Current Site: "  $currentSite.Url

    # load Current Web
    $currentWeb = $ctx.Web
    $ctx.Load($currentWeb)
    $ctx.ExecuteQuery()
    Write-Host "Loading Current Web:" $currentWeb.Url
    
    # load all lists of Site Collection
    $lists = $currentWeb.Lists
    $ctx.Load($lists)
    $ctx.ExecuteQuery()
    Write-Host "Loading all lists of Site Collection :" $lists.Count " item(s)"
    
    # Select File to Restore Content Data
    Write-Host "Select File to Restore Content Data :"
    $fileName = Select-FileDialog -Title "Select CSV file to Restore Content Data:" -Directory $localFileInfo
    $restoreList = Import-Csv $fileName       

    # loop lists need to Restore
    foreach ($rsList in $restoreList){
            
        # loop lists in Site Collection
        foreach($list in $lists)
        {
            # check Internal Name to start backup
            if($list.EntityTypeName -eq $rsList.ListName) {
                Write-Host "Start to restore List Name: " $rsList.ListName -ForegroundColor Yellow
                
                $listCsvPath = $LocalPath + "\" + $list.Title + ".csv"
                $listCsvInfo = Import-Csv $listCsvPath
                
                if($list.BaseType -eq "DocumentLibrary")
                {
                    Write-Host "Start upload file(s) to Library: " $rsList.ListName -ForegroundColor Cyan
                    foreach($rowInfo in $listCsvInfo){
                       Upload-File $list.EntityTypeName $list.Id $list.Title.TrimEnd().TrimStart() $rowInfo
                    }
                                       
                }else{
                    foreach($rowInfo in $listCsvInfo){
                       Create-ListItem $list.EntityTypeName $list.Id $list.Title.TrimEnd().TrimStart() $rowInfo
                    }
                }
            
                Write-Host "End of restore List Name: " $rsList.ListName -ForegroundColor Yellow
                Write-Host "---"
            }            
        }
    }        
}
